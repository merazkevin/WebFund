function cookieRemover(id){
    console.log("yeeee", id)
    let elementToRemove = document.querySelector("."+ id);
    elementToRemove.remove();
}
function cartEmptyAlert(id){
    alert("your cart is empty");
}

function imageswitch(id){
    // console.log(id.src);
    // id.src="./images/assets/succulents-2.jpg"
if
}